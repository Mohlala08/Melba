import { Button } from "./components/ui/button";
import { Card, CardContent } from "./components/ui/card";
import { Badge } from "./components/ui/badge";
import { Phone, Mail, MapPin, Star, Heart, Sparkles } from "lucide-react";
import exampleImage1 from 'figma:asset/8a7e83cc3677dd827e84016dcad0ffd84113d9ae.png';
import exampleImage2 from 'figma:asset/4e15772c068c8fcd07fe47fdd96d469a515edca3.png';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-rose-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-amber-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <nav className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Heart className="h-6 w-6 text-rose-500" />
              <span className="text-xl font-bold text-amber-900">Basetsana Beauty</span>
            </div>
            <div className="hidden md:flex items-center space-x-6">
              <a href="#services" className="text-amber-800 hover:text-rose-600 transition-colors">Services</a>
              <a href="#gallery" className="text-amber-800 hover:text-rose-600 transition-colors">Gallery</a>
              <a href="#contact" className="text-amber-800 hover:text-rose-600 transition-colors">Contact</a>
              <Button className="bg-gradient-to-r from-amber-600 to-rose-600 hover:from-amber-700 hover:to-rose-700">
                Book Now
              </Button>
            </div>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center mb-6">
            <Sparkles className="h-8 w-8 text-amber-500 mr-2" />
            <h1 className="text-4xl md:text-6xl text-amber-900 tracking-wide">
              Basetsana Beauty
            </h1>
            <Sparkles className="h-8 w-8 text-amber-500 ml-2" />
          </div>
          
          <p className="text-lg md:text-xl text-amber-800 mb-8 max-w-3xl mx-auto leading-relaxed">
            "To make all girlies and they presentable, and maintain their natural beauty. 
            Instilling confidence one fibre at a time"
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <Badge variant="secondary" className="bg-amber-100 text-amber-800 px-4 py-2 text-sm">
              Professional Braiding
            </Badge>
            <Badge variant="secondary" className="bg-rose-100 text-rose-800 px-4 py-2 text-sm">
              Expert Plaiting
            </Badge>
            <Badge variant="secondary" className="bg-amber-100 text-amber-800 px-4 py-2 text-sm">
              Premium Hair Washing
            </Badge>
          </div>
          
          <Button size="lg" className="bg-gradient-to-r from-amber-600 to-rose-600 hover:from-amber-700 hover:to-rose-700 px-8 py-3">
            Discover Our Services
          </Button>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-4 bg-white/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl text-amber-900 mb-4">Our Signature Services</h2>
            <p className="text-amber-700 max-w-2xl mx-auto">
              Experience the artistry of natural hair care with our specialized services designed to enhance your beauty and boost your confidence.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-amber-200 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Star className="h-8 w-8 text-amber-700" />
                </div>
                <h3 className="text-xl text-amber-900 mb-4">Professional Braiding</h3>
                <p className="text-amber-700 mb-6">
                  Intricate and beautiful braiding styles that celebrate your natural hair texture and personal style.
                </p>
                <ul className="text-sm text-amber-600 space-y-2">
                  <li>• Goddess braids</li>
                  <li>• Box braids</li>
                  <li>• Cornrows</li>
                  <li>• French braids</li>
                  <li>• Creative patterns</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-rose-50 to-rose-100 border-rose-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-rose-200 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Heart className="h-8 w-8 text-rose-700" />
                </div>
                <h3 className="text-xl text-rose-900 mb-4">Expert Plaiting</h3>
                <p className="text-rose-700 mb-6">
                  Elegant plaiting techniques that create stunning hairstyles perfect for any occasion.
                </p>
                <ul className="text-sm text-rose-600 space-y-2">
                  <li>• Traditional plaits</li>
                  <li>• Dutch plaits</li>
                  <li>• Fishtail braids</li>
                  <li>• Twist styles</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-amber-50 to-rose-50 border-amber-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="bg-gradient-to-r from-amber-200 to-rose-200 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Sparkles className="h-8 w-8 text-amber-700" />
                </div>
                <h3 className="text-xl text-amber-900 mb-4">Premium Hair Washing</h3>
                <p className="text-amber-700 mb-6">
                  Luxurious hair washing treatments that cleanse, nourish, and prepare your hair for styling.
                </p>
                <ul className="text-sm text-amber-600 space-y-2">
                  <li>• Deep cleansing</li>
                  <li>• Scalp massage</li>
                  <li>• Conditioning treatment</li>
                  <li>• Natural products</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section id="gallery" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl text-amber-900 mb-4">Our Beautiful Work</h2>
            <p className="text-amber-700 max-w-2xl mx-auto">
              See the transformation and artistry in our recent hair braiding and styling work.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="overflow-hidden hover:shadow-xl transition-shadow">
              <div className="aspect-square relative">
                <img 
                  src={exampleImage1} 
                  alt="Beautiful golden braids with intricate patterns"
                  className="w-full h-full object-cover"
                />
              </div>
              <CardContent className="p-6">
                <h3 className="text-lg text-amber-900 mb-2">Intricate Golden Braids</h3>
                <p className="text-amber-700 text-sm">
                  Stunning braiding pattern with beautiful golden tones that showcase natural hair beauty.
                </p>
              </CardContent>
            </Card>

            <Card className="overflow-hidden hover:shadow-xl transition-shadow">
              <div className="aspect-square relative">
                <img 
                  src={exampleImage2} 
                  alt="Elegant cornrow braiding pattern"
                  className="w-full h-full object-cover"
                />
              </div>
              <CardContent className="p-6">
                <h3 className="text-lg text-amber-900 mb-2">Elegant Cornrow Design</h3>
                <p className="text-amber-700 text-sm">
                  Professional cornrow styling that combines traditional techniques with modern flair.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 bg-gradient-to-r from-amber-100 to-rose-100">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl text-amber-900 mb-4">Book Your Appointment</h2>
            <p className="text-amber-700 max-w-2xl mx-auto">
              Ready to enhance your natural beauty? Get in touch to schedule your personalized hair care session.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <Card className="bg-white/80 border-amber-200 text-center">
              <CardContent className="p-8">
                <Phone className="h-8 w-8 text-amber-600 mx-auto mb-4" />
                <h3 className="text-lg text-amber-900 mb-2">Call Us</h3>
                <p className="text-amber-700">072 689 4346</p>
              </CardContent>
            </Card>

            <Card className="bg-white/80 border-rose-200 text-center">
              <CardContent className="p-8">
                <Mail className="h-8 w-8 text-rose-600 mx-auto mb-4" />
                <h3 className="text-lg text-rose-900 mb-2">Email Us</h3>
                <p className="text-rose-700">koketsomelba50@gmail.com</p>
              </CardContent>
            </Card>

            <Card className="bg-white/80 border-amber-200 text-center">
              <CardContent className="p-8">
                <MapPin className="h-8 w-8 text-amber-600 mx-auto mb-4" />
                <h3 className="text-lg text-amber-900 mb-2">Visit Us</h3>
                <p className="text-amber-700">Burgesfort, Internet Street</p>
              </CardContent>
            </Card>
          </div>
          
          <div className="text-center mt-12">
            <Button size="lg" className="bg-gradient-to-r from-amber-600 to-rose-600 hover:from-amber-700 hover:to-rose-700 px-12 py-4">
              Schedule Consultation
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-amber-900 text-amber-100 py-12 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Heart className="h-6 w-6 text-rose-400" />
              <span className="text-xl">Basetsana Beauty</span>
            </div>
            <p className="text-amber-200 text-center md:text-right">
              "Instilling confidence one fibre at a time"
            </p>
          </div>
          <div className="border-t border-amber-800 mt-8 pt-8 text-center">
            <p className="text-amber-300 text-sm">
              © 2025 Basetsana Beauty. All rights reserved. | Professional haircare services in Johannesburg
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}